# Ebu's Suits 1.0.0

## Dependencies

Requires [x753's More Suits](https://thunderstore.io/c/lethal-company/p/x753/More_Suits/).

Found the player model in the More Company support Discord server. (I hate the Discordification of support and the resultant walled garden so so so so so so so so so much.) Thanks to "jolly man" (meteheus) though for randomly having a `.blend` file ready to go.